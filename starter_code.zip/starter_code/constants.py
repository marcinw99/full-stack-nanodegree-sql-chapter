STRFTIME_FORMAT = "%m/%d/%Y, %H:%M:%S"
